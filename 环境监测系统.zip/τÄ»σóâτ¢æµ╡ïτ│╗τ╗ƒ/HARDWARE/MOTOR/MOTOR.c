#include "MOTOR.h"
#include "delay.h"

unsigned char Time=7;

void MOTOR_GPIO_Init(void)
{
	  GPIO_InitTypeDef  GPIO_InitStructure;
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB�˿�ʱ��
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_14;				 // �˿�����
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		      //��������
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	  GPIO_Init(GPIOA, &GPIO_InitStructure);	

		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;				 // �˿�����
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		      //��������
	  GPIO_Init(GPIOB, &GPIO_InitStructure);	
}

//˳ʱ��ת��
void MotorCW(void)
{
    unsigned short i;
    for(i=0; i<4; i++)
    {
        Coil_A1;
        delay_ms(Time);
        Coil_B1;
        delay_ms(Time);
        Coil_C1;
        delay_ms(Time);
        Coil_D1;
        delay_ms(Time);
    }
}

//��ʱ��ת��
void MotorCCW(void)
{
    unsigned short i;
    for(i=0; i<4; i++)
    {
        Coil_D1;
        delay_ms(Time);
        Coil_C1;
        delay_ms(Time);
        Coil_B1;
        delay_ms(Time);
        Coil_A1;
        delay_ms(Time);
    }
}

void MotorStop(void)
{
		Coil_OFF;
}


